# Blaze Systems Visual Identity Guidelines

**Version:** 1.0.0  
**Created:** October 20, 2026  
**Identity principle:** dependable infrastructure, connected systems, practical engineering.

## Mark and architecture

The stylized B combines two flame ribbons with a geometric capital B. Three circuit paths represent networking, embedded hardware and payment/control infrastructure. The design is intentionally flat with no embossing, glow, chrome or photograph-like effects.

## Required logo treatments

| ID | Usage | Background | Output |
|---|---|---|---|
| 01 | Primary stacked | Deep navy `#071728` | SVG, PNG, PDF, ORA |
| 02 | Primary stacked | Light/white | SVG, PNG, PDF, ORA |
| 03 | Header horizontal | Deep navy | SVG, PNG, PDF, ORA |
| 04 | Header horizontal | Light/white | SVG, PNG, PDF, ORA |
| 05 | Knockout white | Solid dark | SVG, PNG, PDF |
| 06 | Black/ink mono | White/light | SVG, PNG, PDF |
| 07 | Standalone colored icon | Light | SVG, PNG, PDF |
| 08 | Standalone white icon | Dark | SVG, PNG, PDF |
| 09 | Standalone ink icon | Light | SVG, PNG, PDF |
| 10 | Simplified icon | Mixed app uses | SVG, PNG, PDF |

## Palette

- Ink / body: `#0B1D30` (RGB 11,29,48)
- Deep navy / backgrounds: `#071728` (RGB 7,23,40)
- Blaze Blue / accent: `#0969E8` (RGB 9,105,232)
- Royal / contrast: `#064FC4` (RGB 6,79,196)
- Signal Cyan / circuits: `#25B7F4` (RGB 37,183,244)
- Light blue/silver / inverted secondary type: `#DAE8F6`
- White: `#FFFFFF`

For offset printing, convert using a printer-managed ICC CMYK profile. RGB-to-CMYK direct conversion will shift saturated blue/cyan; ask for a physical proof. No untested CMYK values are asserted.

## Typography

- Primary lockup: outlined Inter Display Bold, uppercase.
- Secondary: outlined Inter Medium, expanded tracking.
- UI suggestions: Inter, fallback to system sans-serif. Do not use unlicensed premium typefaces by default.

## Clear space and minimum sizes

- Keep clear space **at least one-quarter of the symbol's height** on all sides for general layouts (may be adjusted for dense UIs with review).
- Horizontal mark minimum suggested width: 190 px on screens / 45 mm for print.
- Stacked mark minimum suggested width: 135 px on screens / 30 mm for print.
- Detailed icon minimum: 40 px. Prefer simplified `10_icon-micro` at 16-32 px.
- For favicons 16 px, test legibility on the actual browser before launch.

## Correct applications

- Use the right contrast version for the surface.
- Use clean, non-busy backgrounds.
- Keep intrinsic aspect ratio, padding and colors.
- Prefer vectors for banners, shop signage, vinyl and packaging.
- Use solid-color/reversed mono for laser cutting, engraving or single-color print.

## Avoid

- No drop shadow, inner bevel, 3D chrome, glow or lens flare.
- Do not rotate, distort, stretch, skew or rebuild by typing a substitute font without review.
- No gradients on busy photographic backgrounds without high-contrast holding shape.
- Do not change blue/cyan colors per subsystem without an approved sub-brand system.
- Do not use detailed circuit strokes at tiny sizes.

## Application examples

- BlazePwifi / BlazeRental splash: stacked, dark surface.
- Admin console top navigation: horizontal light or dark depending on shell.
- ESP control device: monochrome icon or micro version.
- Rental APK launcher and favicon: micro logo with platform-standard safe zone.
- Paper invoices and receipts: mono dark, tested at thermal printer resolution.

## Release / quality gate

Before treating as a legally established or manufacturing-approved corporate identity: conduct trademark/confusability review; obtain printer color proof; verify SVG imports in your target software; verify Android adaptive icon masking; obtain stakeholder sign-off. This kit has been programmatically built and visually previewed, but those external checks are not represented as completed.
