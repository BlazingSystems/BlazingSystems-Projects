# Blaze Systems — Official Brand Identity Kit v1.0.0

**Brand:** BLAZE SYSTEMS  
**Package date:** 2026-10-20  
**Repository target:** `BlazingSystems/BlazingSystems-Projects`  
**Primary use:** BlazePwifi, BlazeRental, BlazePisonet, vending/coin-operated systems, portals, device management, embedded modules, documentation.

## Contents

- `01_Vector_SVG`: **10 real vector masters**, with **all wordmark glyphs outlined** (no font installation required). SVG paths are individually editable in Inkscape, Illustrator, Figma, Affinity Designer and CorelDRAW.
- `02_Transparent_PNG`: **10 full-resolution transparent renders** plus **three opaque app icons**.
- `03_Print_PDF`: vector PDF exports for print workflow (where Inkscape available).
- `04_Layered_Editors`: ORA OpenRaster layered artwork for Krita/GIMP: symbol, wordmark, descriptor are individually movable/replaceable; *ORA layers are raster, while SVG remains the vector master*.
- `05_Guidelines`: brand guide PDF, palette and publishing notes.
- `06_Previews`: side-by-side preview sheets.
- `build_kit.py`: reproducible generator source (with dependencies described below).

## Primary usage

1. Use `01_primary-stacked_dark` on navy surfaces, `02_primary-stacked_light` on white/light surfaces.
2. Use variants `03` or `04` as horizontal header/logo lockups.
3. Use `07_icon-blue` for interfaces; use `10_icon-micro` for favicons and low-resolution devices (it removes fragile circuit traces).
4. Use `05` or `06` only when color cannot be reproduced.
5. Export final deployment files from SVG, never by rescaling a preview screenshot.

## Vector editing

Open any `.svg` in Inkscape (free), Figma, Illustrator, Affinity Designer, or CorelDRAW. Groups have IDs (`brand-symbol`, `wordmark-BLAZE`, `descriptor-SYSTEMS`, etc.). **Text is converted to paths** so the appearance remains consistent without the Inter font. To reset type, use the Inter family and follow the guide for optical spacing, then review all lockups. The alternate `.ora` files open as **raster layers** in Krita or GIMP; they are not PSD files.

## Reproduce

On a Linux environment with the Inter font installed (font files themselves are not bundled):

```bash
python -m pip install pillow cairosvg fonttools reportlab
python build_kit.py
```

For print PDF exports, install the `inkscape` executable. The packaged `.pdf` files are already ready to use without Inkscape.

## Rights, notes & limitations

The original blue flame/B raster design from the conversation is a **visual reference**. These production SVGs are a separately constructed vector reinterpretation, **not an exact geometric trace**. No third-party trademark clearance or copyright ownership certification has been performed; do a name/logo similarity check and production proof before public registration, sign fabrication or large printing. The Inter typeface was used to produce outlines, under its open-source font license; no font binaries are redistributed. Asset files are intended for the Blaze Systems owner's brand use. No third-party redistribution license is granted by this package.
