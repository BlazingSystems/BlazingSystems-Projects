#!/usr/bin/env python3
"""Blaze Systems identity kit builder. SVG vectors, PNG, PDF, ORA and ZIP.
Requirements: Pillow, cairosvg, fonttools, reportlab. Uses locally installed Inter font;
font binaries are NEVER copied into the outputs. All wordmarks are outlined SVG paths.
"""
import os, io, json, math, zipfile, hashlib, shutil, sys
from pathlib import Path
from datetime import date
from xml.etree import ElementTree as ET
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
import cairosvg
from PIL import Image, ImageDraw, ImageFont, ImageOps
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A4

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'Blaze-Systems-Brand-Kit-v1.0.0'
VEC = OUT/'01_Vector_SVG'; RAS=OUT/'02_Transparent_PNG'; PRINT=OUT/'03_Print_PDF'; LAY=OUT/'04_Layered_Editors'; DOC=OUT/'05_Guidelines'; PREV=OUT/'06_Previews'
for p in (VEC,RAS,PRINT,LAY,DOC,PREV):p.mkdir(parents=True,exist_ok=True)
C={'navy':'#071728','ink':'#0B1D30','blue':'#0969E8','royal':'#064FC4','cyan':'#25B7F4','white':'#FFFFFF','silver':'#DAE8F6','pale':'#F1F6FB','quiet':'#62788D'}
FONT_BOLD='/usr/share/fonts/opentype/inter/InterDisplay-Bold.otf'
FONT_MED='/usr/share/fonts/opentype/inter/Inter-Medium.otf'
FONT_SEMI='/usr/share/fonts/opentype/inter/Inter-SemiBold.otf'
assert all(Path(x).exists() for x in [FONT_BOLD,FONT_MED,FONT_SEMI]), 'Inter font unavailable, configure fonts in script'
class Outline:
    def __init__(self,path):
        self.font=TTFont(path); self.cmap=self.font.getBestCmap(); self.gs=self.font.getGlyphSet(); self.hmtx=self.font['hmtx']; self.em=self.font['head'].unitsPerEm
    def width(self,s,size,track=0):
        scale=size/self.em
        return sum(self.hmtx[self.cmap.get(ord(ch),'space')][0]*scale for ch in s)+max(0,len(s)-1)*track
    def render(self,s,x,base,size,track,fill,mark_at=None,mark_fill=None,group='wordmark'):
        scale=size/self.em; cur=x; out=[f'<g id="{group}" aria-label="{s}">']
        for i,ch in enumerate(s):
            name=self.cmap.get(ord(ch),'space'); pen=SVGPathPen(self.gs); self.gs[name].draw(pen)
            path=pen.getCommands(); color=mark_fill if mark_at is not None and i==mark_at else fill
            if path:out.append(f'<path id="{group}-glyph-{i}" d="{path}" fill="{color}" transform="translate({cur:.4f} {base:.4f}) scale({scale:.7f} {-scale:.7f})"/>')
            cur+=self.hmtx[name][0]*scale + track
        out.append('</g>');return '\n'.join(out)
bold=Outline(FONT_BOLD); medium=Outline(FONT_MED)
# Deliberately simple self-contained original vector reinterpretation, not automated bitmap tracing.
FLAME_TOP='M 114 9 C 149 42 149 81 119 113 C 84 150 61 173 69 213 C 73 231 82 243 94 254 C 69 248 48 232 44 205 C 36 167 58 132 89 99 C 116 70 132 45 114 9 Z'
FLAME_CENTER='M 135 65 C 161 92 171 119 155 149 C 141 175 111 192 110 223 C 110 239 116 251 125 263 C 96 249 87 230 91 205 C 94 182 111 159 130 137 C 150 113 154 90 135 65 Z'
B_MARK='M 151 62 H 183 C 228 62 247 91 244 120 C 242 140 227 153 207 162 C 233 171 247 187 244 210 C 240 240 215 259 183 259 H 139 L 161 232 H 184 C 205 232 216 225 217 211 C 218 195 207 186 184 186 H 173 L 188 159 C 211 155 220 145 217 127 C 215 112 203 101 184 101 H 173 Z'
CIRCUIT=['M 152 224 L 173 205 L 193 205','M 157 238 L 182 222 L 203 222','M 170 181 L 190 164 L 204 164']
# overall symbol in 260 x 275, retains a silhouette at tiny sizes by simplifying traces.
def symbol(color_mode='blue', mini=False):
    if color_mode=='blue':
        fills=['url(#ribbon1)','url(#ribbon2)','url(#bgrad)']; wire=C['cyan']
    elif color_mode=='white':fills=[C['white']]*3; wire=C['white']
    else:fills=[C['ink']]*3; wire=C['ink']
    a=['<g id="brand-symbol" aria-label="Blaze flame B monogram">']
    a += [f'<path id="flame-outer" d="{FLAME_TOP}" fill="{fills[0]}"/>', f'<path id="flame-inner" d="{FLAME_CENTER}" fill="{fills[1]}"/>',f'<path id="letter-b" d="{B_MARK}" fill="{fills[2]}"/>']
    if not mini:
        for i,path in enumerate(CIRCUIT):
            a.append(f'<path id="circuit-{i}" d="{path}" stroke="{wire}" stroke-width="3.6" fill="none" stroke-linejoin="round" stroke-linecap="round"/>')
            # spot just at terminating point; emphasizes electronics, not blinking graphic effects
            x,y=[(193,205),(203,222),(204,164)][i]
            a.append(f'<circle id="contact-{i}" cx="{x}" cy="{y}" r="5" fill="{wire}"/>')
    a.append('</g>');return '\n'.join(a)
DEFS=f'''<defs>
<linearGradient id="ribbon1" x1="0" y1="0" x2="1" y2="1"><stop stop-color="{C['cyan']}"/><stop offset=".55" stop-color="{C['blue']}"/><stop offset="1" stop-color="{C['royal']}"/></linearGradient>
<linearGradient id="ribbon2" x1="0" y1="0" x2=".9" y2="1"><stop stop-color="{C['cyan']}"/><stop offset="1" stop-color="{C['blue']}"/></linearGradient>
<linearGradient id="bgrad" x1="0" y1="0" x2="1" y2=".8"><stop stop-color="{C['blue']}"/><stop offset="1" stop-color="{C['royal']}"/></linearGradient>
</defs>'''

def wrapper(width,height,parts,bg=None,variant=''):
    a=[f'<?xml version="1.0" encoding="UTF-8"?>',f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}" role="img" aria-label="Blaze Systems {variant}">',f'<title>Blaze Systems - {variant}</title>',f'<desc>Original scalable brand mark: flame B and circuitry with Blaze Systems wordmark.</desc>',DEFS]
    if bg:a.append(f'<rect id="background" width="{width}" height="{height}" fill="{bg}"/>')
    a.extend(parts); a.append('</svg>');return '\n'.join(a)

def make_svg(kind,theme='light',mono=None):
    dark=(theme=='dark'); fg=C['white'] if dark else C['ink']; sec=C['silver'] if dark else C['quiet']; accent=C['cyan'] if dark else C['blue']
    if mono is not None:fg=sec=accent=C['white'] if mono=='white' else C['ink']
    mode=mono if mono else 'blue'; parts=[]
    if kind=='stacked':
        w,h=800,850
        parts.append(f'<g id="logo-icon" transform="translate(258 79) scale(1.16)">{symbol(mode)}</g>')
        text='BLAZE';size=108;track=-1.3;tw=bold.width(text,size,track)
        parts.append(bold.render(text,(w-tw)/2,610,size,track,fg,mark_at=None if mono else 2,mark_fill=accent,group='wordmark-BLAZE'))
        size=34;track=15;tw=medium.width('SYSTEMS',size,track)
        parts.append(medium.render('SYSTEMS',(w-tw)/2,675,size,track,sec,group='descriptor-SYSTEMS'))
    elif kind=='horizontal':
        w,h=1280,420
        parts.append(f'<g id="logo-icon" transform="translate(90 54) scale(1.22)">{symbol(mode)}</g>')
        text='BLAZE';size=128;track=-1;parts.append(bold.render(text,450,231,size,track,fg,mark_at=None if mono else 2,mark_fill=accent,group='wordmark-BLAZE'))
        size=39;track=17;parts.append(medium.render('SYSTEMS',454,300,size,track,sec,group='descriptor-SYSTEMS'))
    elif kind=='symbol':
        w,h=512,512;parts.append(f'<g id="logo-icon" transform="translate(76 43) scale(1.52)">{symbol(mode)}</g>')
    elif kind=='micro':
        w,h=512,512;parts.append(f'<g id="logo-icon" transform="translate(76 43) scale(1.52)">{symbol(mode,mini=True)}</g>')
    else:raise ValueError(kind)
    return wrapper(w,h,parts,variant=f'{kind}-{theme}-{mono or "color"}'),w,h

SPECS={
 '01_primary-stacked_dark':('stacked','dark',None),
 '02_primary-stacked_light':('stacked','light',None),
 '03_primary-horizontal_dark':('horizontal','dark',None),
 '04_primary-horizontal_light':('horizontal','light',None),
 '05_monochrome-white':('horizontal','dark','white'),
 '06_monochrome-ink':('horizontal','light','ink'),
 '07_icon-blue':('symbol','light',None),
 '08_icon-white':('symbol','dark','white'),
 '09_icon-ink':('symbol','light','ink'),
 '10_icon-micro':('micro','light',None),
}
svgs={};dims={}
for name,(kind,theme,mono) in SPECS.items():
    src,w,h=make_svg(kind,theme,mono);svgs[name]=src;dims[name]=(w,h)
    (VEC/(name+'.svg')).write_text(src,encoding='utf-8')
    p=RAS/(name+'.png');cairosvg.svg2png(bytestring=src.encode(),write_to=str(p),output_width=w*2,output_height=h*2)
    # Print exports remain fully vector: font glyphs, icon curves and color.
    try:
        import subprocess
        proc=subprocess.run(['inkscape',str(VEC/(name+'.svg')),'--export-filename='+str(PRINT/(name+'.pdf'))],capture_output=True,text=True,timeout=35)
        if proc.returncode:print('WARN PDF',name,proc.stderr[:200])
    except Exception as e:print('WARN PDF',name,e)

# Standalone app icon PNGs with matte square: safe for launchers where transparency isn't desired.
for theme,color,fg in [('navy',C['navy'],'blue'),('blue',C['blue'],'white'),('white',C['white'],'blue')]:
    svg,w,h=make_svg('micro', 'dark' if fg=='white' else 'light', 'white' if fg=='white' else None)
    png=cairosvg.svg2png(bytestring=svg.encode(),output_width=1024,output_height=1024)
    icon=Image.open(io.BytesIO(png)).convert('RGBA')
    bg=Image.new('RGBA',(1024,1024),color)
    # soft rounded-square background with generous safe-area
    mask=Image.new('L',(1024,1024),0);d=ImageDraw.Draw(mask);d.rounded_rectangle((0,0,1023,1023),radius=220,fill=255)
    bg.putalpha(mask);bg.alpha_composite(icon)
    bg.save(RAS/f'appicon-{theme}-1024.png')

# Layered ORA: symbol, wordmark, descriptor transparent raster layers, editable in GIMP/Krita.
def create_ora(name):
    source=svgs[name]; w,h=dims[name]; scale=2
    roots=ET.fromstring(source); ns='{http://www.w3.org/2000/svg}'
    generated={}
    for group,ident in [('symbol','logo-icon'),('wordmark','wordmark-BLAZE'),('descriptor','descriptor-SYSTEMS')]:
        # Keep the three primary groups independently selectable on separate layers.
        chunk=[]
        for child in roots:
            if child.attrib.get('id')==ident:chunk.append(ET.tostring(child,encoding='unicode'))
        svg=wrapper(w,h,chunk,variant=f'{name} {group}')
        generated[group]=cairosvg.svg2png(bytestring=svg.encode(),output_width=w*scale,output_height=h*scale)
    layers=['descriptor','wordmark','symbol']
    layer_nodes=''.join(f'<layer name="{x.title()}" src="data/layer-{x}.png" opacity="1.0" visibility="visible" composite-op="svg:src-over" x="0" y="0"/>' for x in layers)
    stack=f'<?xml version="1.0" encoding="UTF-8"?><image version="0.0.3" w="{w*scale}" h="{h*scale}" name="Blaze Systems {name}"><stack>{layer_nodes}</stack></image>'
    dest=LAY/(name+'.ora')
    with zipfile.ZipFile(dest,'w') as z:
        z.writestr('mimetype','image/openraster',compress_type=zipfile.ZIP_STORED)
        z.writestr('stack.xml',stack)
        for layer,img in generated.items():z.writestr(f'data/layer-{layer}.png',img)
        z.writestr('mergedimage.png',(RAS/(name+'.png')).read_bytes())
for k in ('01_primary-stacked_dark','02_primary-stacked_light','03_primary-horizontal_dark','04_primary-horizontal_light'):create_ora(k)

# Contact sheet: 2 cols x 3 rows; always show both dark and light backgrounds.
W,H=2400,1940
sheet=Image.new('RGB',(W,H),'#EDF3F9'); dr=ImageDraw.Draw(sheet)
font_regular='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';font_bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
f_title=ImageFont.truetype(font_bold,70);f_sub=ImageFont.truetype(font_regular,27);f_label=ImageFont.truetype(font_bold,29)
dr.text((100,64),'BLAZE SYSTEMS',font=f_title,fill=C['navy']);dr.text((104,154),'IDENTITY SYSTEM   /   v1.0.0   /   10 scalable logo variations',font=f_sub,fill=C['quiet'])
cards=[('01_primary-stacked_dark','PRIMARY / DARK',C['navy']),('02_primary-stacked_light','PRIMARY / LIGHT','#FFFFFF'),('03_primary-horizontal_dark','HORIZONTAL / DARK',C['navy']),('04_primary-horizontal_light','HORIZONTAL / LIGHT','#FFFFFF'),('05_monochrome-white','REVERSED / WHITE','#102B46'),('06_monochrome-ink','MONOCHROME / INK','#FFFFFF')]
for i,(name,label,bg) in enumerate(cards):
    col=i%2;row=i//2;x=92+col*1130;y=256+row*485; cw,ch=1078,450
    dr.rounded_rectangle((x,y,x+cw,y+ch),radius=25,fill=bg)
    fg='#D8E4F3' if bg.startswith('#0') or bg=='#102B46' else C['quiet']
    dr.text((x+42,y+31),label,font=f_label,fill=fg)
    pic=Image.open(RAS/(name+'.png')).convert('RGBA');box=(cw-160,ch-135)
    pic.thumbnail(box,Image.Resampling.LANCZOS)
    px=x+(cw-pic.width)//2;py=y+73+(ch-95-pic.height)//2
    sheet.paste(pic,(px,py),pic)
sheet.save(PREV/'all-logo-versions.png',optimize=True)

# Icon row preview separate, high resolution.
icons=Image.new('RGB',(1800,740),'#EEF4FA');dd=ImageDraw.Draw(icons);dd.text((85,55),'BLAZE SYSTEMS  /  ICON FAMILY',font=ImageFont.truetype(font_bold,53),fill=C['navy'])
for i,(file,label) in enumerate([('07_icon-blue','BLUE'),('08_icon-white','REVERSE'),('09_icon-ink','MONO'),('10_icon-micro','MICRO')]):
    x=80+i*420; y=175;bg=C['navy'] if i==1 else C['white']
    dd.rounded_rectangle((x,y,x+375,y+410),radius=28,fill=bg)
    pic=Image.open(RAS/(file+'.png')).convert('RGBA');pic.thumbnail((370,345),Image.Resampling.LANCZOS)
    icons.paste(pic,(x+(375-pic.width)//2,y+25+(350-pic.height)//2),pic)
    dd.text((x+12,y+431),label,font=f_label,fill=C['ink'])
icons.save(PREV/'icon-family.png')

readme='''# Blaze Systems — Official Brand Identity Kit v1.0.0

**Brand:** BLAZE SYSTEMS  
**Package date:** 2026-10-20  
**Repository target:** `BlazingSystems/BlazingSystems-Projects`  
**Primary use:** BlazePwifi, BlazeRental, BlazePisonet, vending/coin-operated systems, portals, device management, embedded modules, documentation.

## Contents

- `01_Vector_SVG`: **10 real vector masters**, with **all wordmark glyphs outlined** (no font installation required). SVG paths are individually editable in Inkscape, Illustrator, Figma, Affinity Designer and CorelDRAW.
- `02_Transparent_PNG`: **10 full-resolution transparent renders** plus **three opaque app icons**.
- `03_Print_PDF`: vector PDF exports for print workflow (where Inkscape available).
- `04_Layered_Editors`: ORA OpenRaster layered artwork for Krita/GIMP: symbol, wordmark, descriptor are individually movable/replaceable; *ORA layers are raster, while SVG remains the vector master*.
- `05_Guidelines`: brand guide PDF, palette and publishing notes.
- `06_Previews`: side-by-side preview sheets.
- `build_kit.py`: reproducible generator source (with dependencies described below).

## Primary usage

1. Use `01_primary-stacked_dark` on navy surfaces, `02_primary-stacked_light` on white/light surfaces.
2. Use variants `03` or `04` as horizontal header/logo lockups.
3. Use `07_icon-blue` for interfaces; use `10_icon-micro` for favicons and low-resolution devices (it removes fragile circuit traces).
4. Use `05` or `06` only when color cannot be reproduced.
5. Export final deployment files from SVG, never by rescaling a preview screenshot.

## Vector editing

Open any `.svg` in Inkscape (free), Figma, Illustrator, Affinity Designer, or CorelDRAW. Groups have IDs (`brand-symbol`, `wordmark-BLAZE`, `descriptor-SYSTEMS`, etc.). **Text is converted to paths** so the appearance remains consistent without the Inter font. To reset type, use the Inter family and follow the guide for optical spacing, then review all lockups. The alternate `.ora` files open as **raster layers** in Krita or GIMP; they are not PSD files.

## Reproduce

On a Linux environment with the Inter font installed (font files themselves are not bundled):

```bash
python -m pip install pillow cairosvg fonttools reportlab
python build_kit.py
```

For print PDF exports, install the `inkscape` executable. The packaged `.pdf` files are already ready to use without Inkscape.

## Rights, notes & limitations

The original blue flame/B raster design from the conversation is a **visual reference**. These production SVGs are a separately constructed vector reinterpretation, **not an exact geometric trace**. No third-party trademark clearance or copyright ownership certification has been performed; do a name/logo similarity check and production proof before public registration, sign fabrication or large printing. The Inter typeface was used to produce outlines, under its open-source font license; no font binaries are redistributed. Asset files are intended for the Blaze Systems owner's brand use. No third-party redistribution license is granted by this package.
'''
(OUT/'README.md').write_text(readme)
style='''# Blaze Systems Visual Identity Guidelines

**Version:** 1.0.0  
**Created:** October 20, 2026  
**Identity principle:** dependable infrastructure, connected systems, practical engineering.

## Mark and architecture

The stylized B combines two flame ribbons with a geometric capital B. Three circuit paths represent networking, embedded hardware and payment/control infrastructure. The design is intentionally flat with no embossing, glow, chrome or photograph-like effects.

## Required logo treatments

| ID | Usage | Background | Output |
|---|---|---|---|
| 01 | Primary stacked | Deep navy `#071728` | SVG, PNG, PDF, ORA |
| 02 | Primary stacked | Light/white | SVG, PNG, PDF, ORA |
| 03 | Header horizontal | Deep navy | SVG, PNG, PDF, ORA |
| 04 | Header horizontal | Light/white | SVG, PNG, PDF, ORA |
| 05 | Knockout white | Solid dark | SVG, PNG, PDF |
| 06 | Black/ink mono | White/light | SVG, PNG, PDF |
| 07 | Standalone colored icon | Light | SVG, PNG, PDF |
| 08 | Standalone white icon | Dark | SVG, PNG, PDF |
| 09 | Standalone ink icon | Light | SVG, PNG, PDF |
| 10 | Simplified icon | Mixed app uses | SVG, PNG, PDF |

## Palette

- Ink / body: `#0B1D30` (RGB 11,29,48)
- Deep navy / backgrounds: `#071728` (RGB 7,23,40)
- Blaze Blue / accent: `#0969E8` (RGB 9,105,232)
- Royal / contrast: `#064FC4` (RGB 6,79,196)
- Signal Cyan / circuits: `#25B7F4` (RGB 37,183,244)
- Light blue/silver / inverted secondary type: `#DAE8F6`
- White: `#FFFFFF`

For offset printing, convert using a printer-managed ICC CMYK profile. RGB-to-CMYK direct conversion will shift saturated blue/cyan; ask for a physical proof. No untested CMYK values are asserted.

## Typography

- Primary lockup: outlined Inter Display Bold, uppercase.
- Secondary: outlined Inter Medium, expanded tracking.
- UI suggestions: Inter, fallback to system sans-serif. Do not use unlicensed premium typefaces by default.

## Clear space and minimum sizes

- Keep clear space **at least one-quarter of the symbol's height** on all sides for general layouts (may be adjusted for dense UIs with review).
- Horizontal mark minimum suggested width: 190 px on screens / 45 mm for print.
- Stacked mark minimum suggested width: 135 px on screens / 30 mm for print.
- Detailed icon minimum: 40 px. Prefer simplified `10_icon-micro` at 16-32 px.
- For favicons 16 px, test legibility on the actual browser before launch.

## Correct applications

- Use the right contrast version for the surface.
- Use clean, non-busy backgrounds.
- Keep intrinsic aspect ratio, padding and colors.
- Prefer vectors for banners, shop signage, vinyl and packaging.
- Use solid-color/reversed mono for laser cutting, engraving or single-color print.

## Avoid

- No drop shadow, inner bevel, 3D chrome, glow or lens flare.
- Do not rotate, distort, stretch, skew or rebuild by typing a substitute font without review.
- No gradients on busy photographic backgrounds without high-contrast holding shape.
- Do not change blue/cyan colors per subsystem without an approved sub-brand system.
- Do not use detailed circuit strokes at tiny sizes.

## Application examples

- BlazePwifi / BlazeRental splash: stacked, dark surface.
- Admin console top navigation: horizontal light or dark depending on shell.
- ESP control device: monochrome icon or micro version.
- Rental APK launcher and favicon: micro logo with platform-standard safe zone.
- Paper invoices and receipts: mono dark, tested at thermal printer resolution.

## Release / quality gate

Before treating as a legally established or manufacturing-approved corporate identity: conduct trademark/confusability review; obtain printer color proof; verify SVG imports in your target software; verify Android adaptive icon masking; obtain stakeholder sign-off. This kit has been programmatically built and visually previewed, but those external checks are not represented as completed.
'''
(DOC/'brand-guidelines.md').write_text(style)
(DOC/'color-palette.json').write_text(json.dumps(C,indent=2)+'\n')
(DOC/'VERSION.md').write_text('''# Version history\n\n- 1.0.0 (2026-10-20): initial professional, flat Blue Blaze Systems vector brand kit. Includes 10 vector configurations, transparent PNGs, app icons, OpenRaster variants, print PDFs and usage documentation.\n\n**Provenance:** based on approved general flame-and-circuit B direction from prior generated artwork; master artwork redrawn as vector geometry.\n''')
# PDF brand guide: clean 3-page document with original preview renders and compact text.
pdf=DOC/'Blaze-Systems-Brand-Guidelines-v1.0.0.pdf'
c=canvas.Canvas(str(pdf),pagesize=A4);pw,ph=A4

def txt(t,x,y,size=11,color=C['ink'],font='Helvetica'):
    c.setFont(font,size);c.setFillColor(HexColor(color));c.drawString(x,y,t)
def img_png(path,x,y,boxw,boxh):
    from reportlab.lib.utils import ImageReader
    im=Image.open(path).convert('RGBA');iw,ih=im.size;k=min(boxw/iw,boxh/ih)
    ww,hh=iw*k,ih*k;c.drawImage(ImageReader(im),x+(boxw-ww)/2,y+(boxh-hh)/2,ww,hh,mask='auto')
for page in range(3):
    c.setFillColor(HexColor(C['pale']));c.rect(0,0,pw,ph,fill=1,stroke=0)
    c.setFillColor(HexColor(C['navy']));c.rect(0,ph-105,pw,105,fill=1,stroke=0)
    txt('BLAZE  SYSTEMS',49,ph-52,23,'#FFFFFF','Helvetica-Bold');txt('IDENTITY STANDARDS   /   v1.0.0',50,ph-79,9,C['silver'])
    txt(f'{page+1} / 3',pw-75,30,9,C['quiet'])
    if page==0:
        txt('The primary mark',48,ph-150,19,C['navy'],'Helvetica-Bold')
        c.setFillColor(HexColor(C['navy']));c.roundRect(43,260,pw-86,410,18,fill=1,stroke=0)
        img_png(RAS/'01_primary-stacked_dark.png',112,290,pw-224,350)
        txt('FLAME  /  TECHNOLOGY  /  CONNECTED INFRASTRUCTURE',50,224,9,C['blue'],'Helvetica-Bold')
        lines=['A structured B-form that references energy, embedded controls and networking.',
               'Flat geometry, no visual effects and restrained typography support long-term use.',
               'The outlines remain crisp from mobile app icons to print signage.']
        for i,line in enumerate(lines):txt(line,50,196-i*21,10)
    elif page==1:
        txt('Logo configurations',48,ph-150,19,C['navy'],'Helvetica-Bold')
        for i,(n,l,bg) in enumerate([('03_primary-horizontal_dark','Horizontal on navy',C['navy']),('04_primary-horizontal_light','Horizontal on white','#FFFFFF'),('05_monochrome-white','Single color reversed',C['navy'])]):
            y=495-i*170
            c.setFillColor(HexColor(bg));c.roundRect(48,y,pw-96,150,8,stroke=0,fill=1)
            img_png(RAS/(n+'.png'),70,y+18,pw-140,115)
            txt(l,55,y-17,9,C['ink'])
    else:
        txt('Color and deployment',48,ph-150,19,C['navy'],'Helvetica-Bold')
        for i,(name,val) in enumerate([('DEEP NAVY',C['navy']),('BLAZE BLUE',C['blue']),('SIGNAL CYAN',C['cyan']),('INK',C['ink']),('WHITE',C['white'])]):
            y=ph-210-i*72;c.setFillColor(HexColor(val));c.roundRect(50,y-22,92,52,5,fill=1,stroke=0)
            c.setStrokeColor(HexColor('#CAD5E0'));c.roundRect(50,y-22,92,52,5,fill=0,stroke=1)
            txt(name,165,y+8,12,C['ink'],'Helvetica-Bold');txt(val,165,y-12,11,C['quiet'])
        txt('Recommended clear space: 25% of symbol height.',50,196,10)
        txt('Minimum horizontal width: 190 px / 45 mm.',50,179,10)
        txt('At 16-32 px, use the simplified icon without micro-circuits.',50,162,10)
        txt('Do not stretch, glow, bevel or recolor the mark.',50,145,10)
        txt('Before trademark filing, verify name/design uniqueness.',50,128,10)
    c.showPage()
c.save()

# Single page license / publishing note
(DOC/'PUBLISHING_NOTES.md').write_text('''# Publishing notes (v1.0.0)\n\nThis package contains brand assets generated and assembled for Blaze Systems. Brand name, logos and other product marks should be treated as proprietor-controlled assets. This kit does not grant the public a license to reuse the trademark or imply that a trademark registry has approved it.\n\nSVG files are original vector reconstructions inspired by the owner-approved concept, not pixel-perfect outlines from the previously generated image. Standard open SVG makes the logo editable in Inkscape, Adobe Illustrator, Figma and Affinity. OpenRaster `.ora` editing uses raster layers; it is a practical PSD alternative, not a PSD.\n\nPublished version: 1.0.0; date: 2026-10-20.\n''')

# Copy reproducible generator script into branded ZIP too; when running it from ZIP root, it creates kit dir.
shutil.copyfile(__file__,OUT/'build_kit.py')
# Integrity list with sha256, generated before manifest itself.
manifest=[]
for p in sorted(OUT.rglob('*')):
    if p.is_file():manifest.append({'path':str(p.relative_to(OUT)).replace('\\','/'),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(OUT/'manifest.json').write_text(json.dumps({'kit':'Blaze Systems','version':'1.0.0','files':manifest},indent=2)+'\n')
zip_dest=ROOT/'Blaze-Systems-Official-Brand-Kit-v1.0.0.zip'
with zipfile.ZipFile(zip_dest,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file():z.write(p,arcname=str(Path(OUT.name)/p.relative_to(OUT)))
# output single file list + validation
print('ZIP:',zip_dest,'bytes:',zip_dest.stat().st_size)
print('KIT:',OUT,'files:',len(manifest))
for n in SPECS:print(n,dims[n])
