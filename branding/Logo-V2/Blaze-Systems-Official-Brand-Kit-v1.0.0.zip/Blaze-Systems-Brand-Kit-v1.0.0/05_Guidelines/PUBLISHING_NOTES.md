# Publishing notes (v1.0.0)

This package contains brand assets generated and assembled for Blaze Systems. Brand name, logos and other product marks should be treated as proprietor-controlled assets. This kit does not grant the public a license to reuse the trademark or imply that a trademark registry has approved it.

SVG files are original vector reconstructions inspired by the owner-approved concept, not pixel-perfect outlines from the previously generated image. Standard open SVG makes the logo editable in Inkscape, Adobe Illustrator, Figma and Affinity. OpenRaster `.ora` editing uses raster layers; it is a practical PSD alternative, not a PSD.

Published version: 1.0.0; date: 2026-10-20.
