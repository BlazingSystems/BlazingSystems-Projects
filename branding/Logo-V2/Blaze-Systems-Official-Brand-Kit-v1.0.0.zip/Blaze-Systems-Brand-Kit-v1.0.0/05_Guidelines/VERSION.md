# Version history

- 1.0.0 (2026-10-20): initial professional, flat Blue Blaze Systems vector brand kit. Includes 10 vector configurations, transparent PNGs, app icons, OpenRaster variants, print PDFs and usage documentation.

**Provenance:** based on approved general flame-and-circuit B direction from prior generated artwork; master artwork redrawn as vector geometry.
